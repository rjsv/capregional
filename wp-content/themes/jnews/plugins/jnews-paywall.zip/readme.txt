Change Logs :

== 7.0.5 ==
- [BUG] FIX String transalation
- [IMPROVEMENT] Add more detail to settings description
- [IMPROVEMENT] Redirect to checkout after login when click buy product

== 7.0.4 ==
- [BUG] Fix conflict validate Paypal IPN
- [BUG] Fix reCAPTCHA on paywall item
- [IMPROVEMENT] Change text description of login and register popup for paywall package

== 7.0.3 ==
- [IMPROVEMENT] Better animation for login form popup

== 7.0.2 ==
- [BUG] Fix API Operation Request not found on Stripe

== 7.0.1 ==
- [BUG] Fix active plugin issue

== 7.0.0 ==
- First Release