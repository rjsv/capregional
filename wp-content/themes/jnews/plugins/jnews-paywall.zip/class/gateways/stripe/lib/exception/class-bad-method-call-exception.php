<?php

namespace JNews\Paywall\Gateways\Stripe\Lib\Exception;

class Bad_Method_Call_Exception extends \BadMethodCallException implements Exception_Interface {

}
