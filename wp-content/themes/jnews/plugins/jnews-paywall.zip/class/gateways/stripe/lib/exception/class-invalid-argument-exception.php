<?php

namespace JNews\Paywall\Gateways\Stripe\Lib\Exception;

use Throwable;

class Invalid_Argument_Exception extends \InvalidArgumentException implements Exception_Interface {
	
}
